package com.exemplo.seuapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class `SecondActivity.kt` : AppCompatActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var tvCoordenadas: TextView
    private lateinit var btnObterLocalizacao: Button
    private lateinit var btnVoltar: Button

    private val LOCATION_PERMISSION_REQ_CODE = 1000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        tvCoordenadas = findViewById(R.id.tvCoordenadas)
        btnObterLocalizacao = findViewById(R.id.btnObterLocalizacao)
        btnVoltar = findViewById(R.id.btnVoltarTela1)

        // Inicializar o cliente de localização do Google Play Services
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        btnObterLocalizacao.setOnClickListener {
            obterLocalizacao()
        }

        // Botão para voltar para a Tela 1
        btnVoltar.setOnClickListener {
            finish() // Fecha a Activity atual e retorna para a tela anterior (MainActivity)
        }
    }

    private fun obterLocalizacao() {
        // Verificar se as permissões de localização foram concedidas pelo usuário
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            // Solicitar permissão ao usuário
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                LOCATION_PERMISSION_REQ_CODE
            )
            return
        }

        // Se a permissão já foi concedida, busca a última localização conhecida
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude
                tvCoordenadas.text = "Latitude: $latitude\nLongitude: $longitude"
            } else {
                tvCoordenadas.text = "Não foi possível obter a localização atual.\nCertifique-se que o GPS está ligado."
            }
        }
    }

    // Tratar o retorno da solicitação de permissões em tempo de execução
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQ_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                obterLocalizacao()
            } else {
                Toast.makeText(this, "Permissão de localização negada pelo usuário.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}