package com.exemplo.seuapp

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class 'R.MainActivity.kt' : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var sensorProximidade: Sensor? = null
    private lateinit var tvStatus: TextView
    private lateinit var btnTrocarTela: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatusProximidade)
        btnTrocarTela = findViewById(R.id.btnIrParaTela2)

        // 1. Inicializar o Sensor Manager e o Sensor de Proximidade
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorProximidade = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)

        if (sensorProximidade == null) {
            tvStatus.text = "Este dispositivo não possui sensor de proximidade."
        }

        // 2. Botão para trocar para a Tela 2 via Intent
        btnTrocarTela.setOnClickListener {
            val intent = Intent(this, `SecondActivity.kt`::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        // Registrar listener do sensor ao voltar para esta tela
        sensorProximidade?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        // Desregistrar listener do sensor para economizar bateria ao mudar de tela
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_PROXIMITY) {
            val distancia = event.values[0]
            val alcanceMaximo = sensorProximidade?.maximumRange ?: 0f

            if (distancia < alcanceMaximo) {
                tvStatus.text = "Objeto PRÓXIMO ao sensor!\n(Valor: $distancia cm)"
            } else {
                tvStatus.text = "Objeto AFASTADO do sensor.\n(Valor: $distancia cm)"
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}